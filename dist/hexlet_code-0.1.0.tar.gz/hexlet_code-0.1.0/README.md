### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArsenyChutker/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArsenyChutker/python-project-49/actions)
https://asciinema.org/a/uhJMRPIrR0PTKCTA8B5h0V0YI - brain-even
https://asciinema.org/a/XdaGMe5s4SBajZ8Bxo7y3mfjO - brain-calc
https://asciinema.org/a/FLUAD7143XGvK7PCdfjhzs0tQ - brain-gcd
https://asciinema.org/a/xqRdIxnTUx1v43E2nnFzvLDC4 - brain-progression
https://asciinema.org/a/EAmbr5wncSwgrSJyZlk06zak2 - brain-prime


